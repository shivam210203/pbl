package calculus;
import java.lang.Math;
import java.util.*;

public class calcos{
   
       Scanner sc=new Scanner(System.in);   

   public void calcos(){

       double theta,thetar;
       double value;

       System.out.print("enter angle:");
       theta=sc.nextDouble();
       thetar=Math.toRadians(theta);

       value = ((-1)*(Math.sin(thetar)));

       System.out.println("d/dx is"+value);

       
    }
}