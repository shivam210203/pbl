package calculus;

import java.lang.*;
import java.util.*;

public class calintxpown{
   
   Scanner sc=new Scanner(System.in);

   public void calintxpown(){

       int n;

       System.out.print("integration x^ ");
       n=sc.nextInt();
       
      



       System.out.printf(" integration is x^ %d / %d",n+1,n+1);

       
    }
}