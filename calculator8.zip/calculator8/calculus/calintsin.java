package calculus;

import java.lang.*;
import java.util.*;

public class calintsin{
   
   Scanner sc=new Scanner(System.in);

   public void calintsin(){

       double theta,thetar;
      double value;

       System.out.print("enter angle:");
       theta=sc.nextDouble();
       thetar=Math.toRadians(theta);

       value = ((-1)*Math.cos(thetar));

       System.out.println("integration in radian is " +value);

       
    }
}