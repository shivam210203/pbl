package calculus;

import java.lang.*;
import java.util.*;

public class calxpown{
   
   Scanner sc=new Scanner(System.in);

   public void calxpown(){

       int n;
       double value;

       System.out.print("d/dx x^ ");
       n=sc.nextInt();
       
      



       System.out.printf("derivative is %dx^%d",n,n-1);

       
    }
}