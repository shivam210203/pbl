package calculus;

import java.lang.*;
import java.util.*;

public class callogx{
 
   Scanner sc=new Scanner(System.in);

    public void callogx(){
    
    double n,value;
    System.out.print("d/dx(log ");
    n=sc.nextDouble();

     value = 1/n;
    System.out.print("d/dx is"+value);

       
    }
}