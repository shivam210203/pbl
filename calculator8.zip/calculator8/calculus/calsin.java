package calculus;

import java.lang.*;
import java.util.*;

public class calsin{
   
   Scanner sc=new Scanner(System.in);

   public void calsin(){

       double theta,thetar;
       double value;

       System.out.print("enter angle:");
       theta=sc.nextDouble();
       thetar=Math.toRadians(theta);

        value = Math.cos(thetar);

       System.out.println("d/dx is "+value);

       
    }
}