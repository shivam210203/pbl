package mensuration;

import java.util.*;

public class trg{
  Scanner sc = new Scanner(System.in);
  public void trg(){
       
        double h,b,area,perimeter;
        System.out.print("Enter height of triangle:");
        h=sc.nextDouble();
        System.out.print("Enter breadth of triangle:");
        b=sc.nextDouble();
        area= (1%2)*h*b;

        System.out.println("Area is "+area);


    }

}