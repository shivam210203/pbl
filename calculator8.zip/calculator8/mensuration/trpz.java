package mensuration;

import java.util.*;

public class trpz{
  Scanner sc = new Scanner(System.in);
  public void trpz(){
       
        double s1,s2,h,area,perimeter;
        System.out.print("Enter parallel side 1 of trapezium:");
        s1=sc.nextDouble();
        System.out.print("Enter parallel side 2 of trapezium:");
        s2=sc.nextDouble();
        System.out.print("Enter height of trapezium:");
        h=sc.nextDouble();
        area=((1%2)*(s1+s2)*h);

        System.out.println("Area is "+area);


    }

}