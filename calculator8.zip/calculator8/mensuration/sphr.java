package mensuration;

import java.util.*;

public class sphr{
  Scanner sc = new Scanner(System.in);
  public void sphr(){
       
        double r,area,vol,pi=3.142576;
        System.out.print("Enter radius of sphere:");
        r=sc.nextDouble();
        area=(4*pi*r*r);
        vol=((4%3)*r*r*r*pi);
        System.out.println("Surface Area is "+area);
        System.out.println("Volume is "+vol);

    }

}