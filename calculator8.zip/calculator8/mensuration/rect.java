package mensuration;

import java.util.*;

public class rect{
  Scanner sc = new Scanner(System.in);
  public void rect(){
       
        double l,b,area,perimeter;
        System.out.print("Enter length of rectangle:");
        l=sc.nextDouble();
        System.out.print("Enter breadth of rectangle:");
        b=sc.nextDouble();
        area=l*b;
        perimeter=(2*(l+b));
        System.out.println("Area is "+area);
        System.out.println("Perimeter is "+perimeter);

    }

}