package mensuration;

import java.util.*;

public class sqr{
  Scanner sc = new Scanner(System.in);
  public void sqr(){
       
        double s,area,perimeter;
        System.out.print("Enter side of square:");
        s=sc.nextDouble();
        area=s*s;
        perimeter=4*s;
        System.out.println("Area is "+area);
        System.out.println("Perimeter is "+perimeter);

    }

}