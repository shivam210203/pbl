package mensuration;

import java.util.*;

public class cube{
  Scanner sc = new Scanner(System.in);
  public void cube(){
       
        double s,area,vol;
        System.out.print("Enter side of cube:");
        s=sc.nextDouble();
        area=(s*s*6);
        vol=(s*s*s);
        System.out.println("Surface Area is "+area);
        System.out.println("Volume is "+vol);

    }

}