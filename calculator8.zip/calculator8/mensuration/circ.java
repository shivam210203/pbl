package mensuration;

import java.util.*;

public class circ{
  Scanner sc = new Scanner(System.in);
  public void circ(){
       
        double r,area,perimeter,pi=3.142576;
        System.out.print("Enter side of square:");
        r=sc.nextDouble();
        area=(pi*r*r);
        perimeter=(2*pi*r);
        System.out.println("Area is "+area);
        System.out.println("Perimeter is "+perimeter);

    }

}