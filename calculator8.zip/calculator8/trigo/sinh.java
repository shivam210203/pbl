package trigo;
import java.lang.Math;
import java.util.Scanner;

public class sinh{

    public void sinh(){
   
                double num;
                Scanner sc=new Scanner(System.in);
                System.out.println("enter angle:");
		num=sc.nextDouble();
                num=Math.toRadians(num);
		

		// Applying absolute math function and
		// storing it in integer variable
		double value = Math.sinh(num);
                

		// Printing value after applying inverse cosx function
		System.out.printf("%2f",value);
	}
    
}