package trigo;
import java.lang.Math;
import java.util.Scanner;

public class invcot{
     
     public void invcot(){
    
                double num;
                Scanner sc=new Scanner(System.in);
                System.out.println("enter number:");
		num=sc.nextDouble();
		

		// Applying absolute math function and
		// storing it in integer variable
		double value = Math.atan(1/num);

		// Printing value after applying inverse cosx function
		System.out.printf("%2f radian",value);
                System.out.printf("\n= %2f degrees",Math.toDegrees(value));
	}
    }
