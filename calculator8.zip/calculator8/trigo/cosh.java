package trigo;
import java.lang.Math;
import java.util.Scanner;

public class cosh{

     public void cosh()
       {
   
                double num;
                Scanner sc=new Scanner(System.in);
                System.out.println("cosh ");
		num=sc.nextDouble();
                num=Math.toRadians(num);
		

		// Applying absolute math function and
		// storing it in integer variable
		double value = Math.cosh(num);

		// Printing value after applying inverse cosx function
		System.out.printf("%2f",value);
	   }
       
}