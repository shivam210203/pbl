package trigo;
import java.lang.Math;
import java.util.Scanner;

public class csc{
     public void csc()

	
	{       
                double num;
                Scanner sc=new Scanner(System.in);
                System.out.println("csc ");
		num=sc.nextDouble();
                num=Math.toRadians(num);
		

		// Applying absolute math function and
		// storing it in integer variable
		double value = Math.sin(num);

		// Printing value after applying inverse cosx function
		System.out.printf("%2f",1/value);
	}
    
}