package trigo;
import java.lang.Math;
import java.util.Scanner;

public class sec{

	public void sec()
        {
	  
	           
                double num;
                Scanner sc=new Scanner(System.in);
                System.out.println("sec ");
		num=sc.nextDouble();
                num=Math.toRadians(num);

		

		// Applying absolute math function and
		// storing it in integer variable
		double value = Math.cos(num);
                

		// Printing value after applying inverse cosx function
		System.out.printf("%.2f",1/value);
             }
	
}