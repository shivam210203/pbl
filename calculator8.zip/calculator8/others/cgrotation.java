package others;
import java.lang.Math;
import java.util.Scanner;

public class cgrotation
{  
           
      public void cgrotation(){       
         double x,y,xf,yf;
         double cost,sint,theta;
         Scanner sc=new Scanner(System.in);

	 System.out.println("enter initial coordinates of x:");
         x=sc.nextDouble();
	 System.out.println("enter initial coordinates of y:");
         y=sc.nextDouble();
	 System.out.println("enter rotation angle in degree:");
         theta=sc.nextDouble();
         theta=Math.toRadians(theta);
         cost=Math.cos(theta);
         sint=Math.sin(theta);
         xf= (x*cost)-(y*sint);
         yf= (x*sint)-(y*cost);

	 System.out.println("final position of x is:"+xf);
	 System.out.println("final position of y is:"+yf);
       }                     
 }