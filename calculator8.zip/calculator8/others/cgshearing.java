package others;
import java.lang.Math;
import java.util.Scanner;


public class cgshearing
{  
           
      public void cgshearing(){       
         int x,y,shx,shy,xf,yf;
         Scanner sc=new Scanner(System.in);

	 System.out.println("enter initial coordinates of x:");
         x=sc.nextInt();
	 System.out.println("enter initial coordinates of y:");
         y=sc.nextInt();
	 System.out.println("enter shearfactor of x:");
         shx=sc.nextInt();
	 System.out.println("enter shearfactor of y:");
         shy=sc.nextInt();


         xf=(x+(shx*y));
         yf=(y+(shy*x));

	 System.out.println("final position of x is:"+xf);
	 System.out.println("final position of y is:"+yf);
       }                     
 }