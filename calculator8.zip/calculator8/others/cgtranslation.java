package others;
import java.lang.Math;
import java.util.Scanner;

public class cgtranslation
{  
           
      public void cgtranslation(){       
         int x,y,tx,ty,xf,yf;
         Scanner sc=new Scanner(System.in);

	 System.out.println("enter initial coordinates of x:");
         x=sc.nextInt();
	 System.out.println("enter initial coordinates of y:");
         y=sc.nextInt();
	 System.out.println("enter translation of x:");
         tx=sc.nextInt();
	 System.out.println("enter translation of y:");
         ty=sc.nextInt();


         xf=x+tx;
         yf=y+ty;

	 System.out.println("final position of x is:"+xf);
	 System.out.println("final position of y is:"+yf);
       }                     
 }