import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class MyFrame
	extends JFrame
	implements ActionListener
{
        final JTextField tf=new JTextField();
	private Container c;
	private JLabel title;
	private JTextField screen;
	private JButton sub1;
	private JButton sub2;
	private JButton sub3;
	private JButton sub5;
	private JButton sub4;
	private JButton sub6;
	private JButton sub7;
	private JButton sub8;
	private JButton sub9;
	private JButton sub0;

public MyFrame()
	{
		setTitle("PBL SCIENTIFIC CALCULATOR");
		setBounds(300, 90, 900, 600);    /*TO SET WINDOW SIZE*/
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);

		c = getContentPane();
		c.setLayout(null);

		title = new JLabel("PBL MINI CALCULATOR");
		title.setFont(new Font("Arial", Font.PLAIN, 30));
		title.setSize(300, 30);
		title.setLocation(300, 30);
		c.add(title);

		sub1 = new JButton("1");
		sub1.setFont(new Font("Arial", Font.PLAIN, 15));
		sub1.setSize(60, 40);
		sub1.setLocation(150, 150);
		sub1.addActionListener(new ActionListner(){
                public void actionPerformd(ActionEvent e){
                   tf.settext("2");}
                 } );
		c.add(sub1);


		sub2= new JButton("2");
		sub2.setFont(new Font("Arial", Font.PLAIN, 15));
		sub2.setSize(60,40);
		sub2.setLocation(250, 150);
		/*sub.addActionListener(this);*/
		c.add(sub2);

		sub3 = new JButton("3");
		sub3.setFont(new Font("Arial", Font.PLAIN, 15));
		sub3.setSize(60,40);
		sub3.setLocation(350, 150);
		/*sub.addActionListener(this);*/
		c.add(sub3);

		sub4 = new JButton("4");
		sub4.setFont(new Font("Arial", Font.PLAIN, 15));
		sub4.setSize(60,40);
		sub4.setLocation(150, 250);
		/*sub.addActionListener(this);*/
		c.add(sub4);

		sub5 = new JButton("5");
		sub5.setFont(new Font("Arial", Font.PLAIN, 15));
		sub5.setSize(60,40);
		sub5.setLocation(250, 250);
		/*sub.addActionListener(this);*/
		c.add(sub5);

		sub6 = new JButton("6");
		sub6.setFont(new Font("Arial", Font.PLAIN, 15));
		sub6.setSize(60,40);
		sub6.setLocation(350, 250);
		/*sub.addActionListener(this);*/
		c.add(sub6);

		sub7 = new JButton("7");
		sub7.setFont(new Font("Arial", Font.PLAIN, 15));
		sub7.setSize(50,40);
		sub7.setLocation(150, 350);
		/*sub.addActionListener(this);*/
		c.add(sub7);

		sub8 = new JButton("8");
		sub8.setFont(new Font("Arial", Font.PLAIN, 15));
		sub8.setSize(60,40);
		sub8.setLocation(250, 350);
		/*sub.addActionListener(this);*/
		c.add(sub8);

		sub9 = new JButton("9");
		sub9.setFont(new Font("Arial", Font.PLAIN, 15));
		sub9.setSize(60,40);
		sub9.setLocation(350, 350);
		/*sub.addActionListener(this);*/
		c.add(sub9);

		sub0 = new JButton("0");
		sub0.setFont(new Font("Arial", Font.PLAIN, 15));
		sub0.setSize(60,40);
		sub0.setLocation(250, 450);
		/*sub.addActionListener(this);*/
		c.add(sub0);

		
		setVisible(true);
	}
}
class pblc{

	public static void main(String[] args) throws Exception
	{
		MyFrame f = new MyFrame();
	}
}



