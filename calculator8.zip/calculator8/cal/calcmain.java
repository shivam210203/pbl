import arithmatic.*;
import trigo.*;
import basen.*;
import matrix.*;
import java.util.Scanner;
import algebra.*;
import calculus.*;
import others.*;
import statistics.*;





class calcmain{
   public static void main(String args[])
         {  int n,ch,num;
            Scanner sc=new Scanner(System.in);
            System.out.println("1.sum 2.difference 3.product 4.division 5.modulus 6.sqrt");
            System.out.println("7.sin 8.cos 9.tan 10.sin^-1 11.cos^-1 12.tan^-1 13.sinh 14.cosh 15.tanh 16.Bin");
            System.out.println("18.matrix multiplication 19.matrix addition ");

            System.out.println("enter choice:");
            ch=sc.nextInt();
            switch(ch)
            {
             case 1:
                   {
                    sum a=new sum();
                    a.sum();
                    break;
                   }
            case 2:
                   {
                    difference obj=new difference();
                    obj.diff();
                    break;
                   }
            case 3:
                   {
                    multiplication obj=new multiplication();
                    obj.mult();
                    break;
                   }
            case 4:
                   {
                    division obj=new division();
                    obj.div();
                    break;
                   }
            case 5:
                   {
                    modulus obj=new modulus();
                    obj.mod();
                    break;
                   }
            case 6:
                   {
                    square_root obj=new square_root();
                    obj.sqrt();
                    break;
                   }
             case 7:
                   {
                    sin a=new sin();
                    a.sin();
                    break;
                   }
             case 8:
                   {
                    cos a=new cos();
                    a.cos();
                    break;
                   }
             case 9:
                   {
                    tan a=new tan();
                    a.tan();
                    break;
                   }
              case 10:
                   {
                    invsin a=new invsin();
                    a.invsin();
                    break;
                   }
             case 11:
                   {
                    invcos a=new invcos();
                    a.invcos();
                    break;
                   }
             case 12:
                   {
                    invtan a=new invtan();
                    a.invtan();
                    break;
                   }
             case 13:
                   {
                    sinh a=new sinh();
                    a.sinh();
                    break;
                   }
             case 14:
                   {
                    cosh a=new cosh();
                    a.cosh();
                    break;
                   }
             case 15:
                   {
                    tanh a=new tanh();
                    a.tanh();
                    break;
                   }
             case 16:
                   {

                    tobin a=new tobin();
                    System.out.print("bin ");
                    int in=sc.nextInt();
                    a.tobin(in);
                    break;
                   }
             case 17:
                   {

                    //System.out.println("dec ");
                   //System.out.println();
                    todec a=new todec();
                    //int str=sc.nextInt();
                    a.todec();
                    break;
                   }
             case 18:
                   {
                    matmul a=new matmul();
                    a.matmul();
                    break;
                   }
             case 19:
                   {
                    matadd a=new matadd();
                    a.matadd();
                    break;
                   }
             case 20:
                   {
                    csc a=new csc();
                    a.csc();
                    break;
                   }
             case 21:
                   {
                    sec a=new sec();
                    a.sec();
                    break;
                   }
             case 22:
                   {
                    cot a=new cot();
                    a.cot();
                    break;
                   }

             case 23:
                   {
                    csch a=new csch();
                    a.csch();
                    break;
                   }

             case 24:
                   {
                    sech a=new sech();
                    a.sech();
                    break;
                   }

             case 25:
                   {
                    coth a=new coth();
                    a.coth();
                    break;
                   }
             case 26:
                   {
                    invcsc a=new invcsc();
                    a.invcsc();
                    break;
                   }
             case 27:
                   {
                    invsec a=new invsec();
                    a.invsec();
                    break;
                   }
             case 28:
                   {
                    invcot a=new invcot();
                    a.invcot();
                    break;
                   }
             case 29:
                   {
                    ln a=new ln();
                    a.ln();
                    break;
                   }
             case 30:
                   {
                    ln10 a=new ln10();
                    a.ln10();
                    break;
                   }
             case 31:
                   {
                    lnab a=new lnab();
                    a.lnab();
                    break;
                   }
             case 32:
                   {
                    cbrt a=new cbrt();
                    a.scbrt();
                    break;
                   }

             case 33:
                   {
                    power a=new power();
                    a.power();
                    break;
                   }
             case 34:
                   {
	            System.out.print("fact ");
		    num=sc.nextInt();
                    fact a=new fact();
                    a.fact(num);
                    break;
                   }  
             case 35:
                   {
                    ncr a=new ncr();
                    a.ncr();
                    break;
                   }
//npr
              case 37:
                   {
                    calcos a=new calcos();
                    a.calcos();
                    break;
                   } 
             case 38:
                   {
                    calsin a=new calsin();
                    a.calsin();
                    break;
                   }
             case 39:
                   {
                    callogx a=new callogx();
                    a.callogx();
                    break;
                   }
             case 40:
                   {
                    calxpown a=new calxpown();
                    a.calxpown();
                    break;
                   }
             case 41:
                   {
                    calintcos a=new calintcos();
                    a.calintcos();
                    break;
                   }
             case 42:
                   {
                    calintsin a=new calintsin();
                    a.calintsin();
                    break;
                   }
             case 43:
                   {
                    calintxpown a=new calintxpown();
                    a.calintxpown();
                    break;
                   } 


             case 44:
                   {
                    matsub a=new matsub();
                    a.matsub();
                    break;
                   }
             case 45:
                   {
                    mattranspose a=new mattranspose();
                    a.mattranspose();
                    break;
                   }
             case 46:
                   {
                    matconstmul a=new matconstmul();
                    a.matconstmul();
                    break;
                   }
//matinv

             case 47:
                   {
                    binsum a=new binsum();
                    a.binsum();
                    break;
                   }     
             case 48:
                   {
                    binmul a=new binmul();
                    a.binmul();
                    break;
                   }    
             case 49:
                   {
                    bindif a=new bindif();
                    a.bindif();
                    break;
                   }    
             case 50:
                   {
                    bindiv a=new bindiv();
                    a.bindiv();
                    break;
                   }     
             case 51:
                   {
                    cgtranslation a=new cgtranslation();
                    a.cgtranslation();
                    break;
                   }     
             case 52:
                   {
                    cgrotation a=new cgrotation();
                    a.cgrotation();
                    break;
                   }  
             case 53:
                   {
                    cgshearing a=new cgshearing();
                    a.cgshearing();
                    break;
                   }     
             case 54:
                   {
                    cgscaling a=new cgscaling();
                    a.cgscaling();
                    break;
                   }  
             case 55:
                   {
                    mean a=new mean();
                    a.mean();
                    break;
                   }
             case 56:
                   {
                    median a=new median();
                    a.median();
                    break;
                   }      

            }
        }
   }
