package arithmatic;
import java.lang.Math;
import java.util.Scanner;

public class modulus{

	
	
	   public void mod(){
                int num;
                Scanner sc=new Scanner(System.in);
                System.out.print("abs ");
		num=sc.nextInt();
		

		// Applying absolute math function and
		// storing it in integer variable
		int value = Math.abs(num);

		// Printing value after applying absolute function
		System.out.println(
			 + value);
	}
}
