package arithmatic;
import java.lang.*;
import java.util.*;

public class ln{
 
  public void ln()
    {
     Double value;    
     Scanner sc=new Scanner(System.in);
     System.out.printf("Ln ");
     value=sc.nextDouble();
     System.out.println(Math.log(value));
    }
}



     
   