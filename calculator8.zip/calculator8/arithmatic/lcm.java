package arithmatic;

import java.util.*;



public class lcm  
{  Scanner sc =new Scanner(System.in);
public void lcm()  
{   
int a,b,gcd = 1;  
System.out.print("Enter first Number:");
a=sc.nextInt();
System.out.print("Enter second Number:");
b=sc.nextInt();
 
for(int i = 1; i <= a && i <= b; ++i)   
 {  
  if(a % i == 0 && b % i == 0)   
  gcd = i;  
 }     
  int lcm = (a * b) / gcd;  
  System.out.printf("The LCM of %d and %d is %d.\n", a, b, lcm);  
 }  
}  