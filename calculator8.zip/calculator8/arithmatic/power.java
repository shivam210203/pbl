package arithmatic;
import java.util.*;
import java.lang.*;
public class power{
  public void power(){
    double num,value,pow;
    Scanner sc = new Scanner(System.in);
    System.out.println("enter number:");
    num=sc.nextDouble();
    System.out.println("enter power:");
    pow=sc.nextDouble();
    value=Math.pow(num,pow);
    System.out.println(value);
  }
}

    