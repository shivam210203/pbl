package arithmatic;
import java.lang.Math;
import java.util.Scanner;

public class cbrt{

	public void scbrt(){
	      
                double num;
                Scanner sc=new Scanner(System.in);
                System.out.print("cube root ");
		num=sc.nextInt();
		

		// Applying absolute math function and
		// storing it in integer variable
		double value = Math.cbrt(num);

		// Printing value after sqrtfunction
		System.out.println(
			 + value);
	}

}