package arithmatic;
import java.lang.*;
import java.util.Scanner;

public class Percent {
   public void percent{
      float percentage;
      float total_value;
      float value;
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter value:");
      value = sc.nextFloat();

      System.out.println("Enter total value:");
      total_value = sc.nextFloat();

      percentage = (float)((value / total_value) * 100);
      System.out.println("Percentage ::"+ percentage);
   }
}