package arithmatic;
import java.lang.*;
import java.util.*;

public class ln10{
 
  public void ln10()
    {
     Double value;    
     Scanner sc=new Scanner(System.in);
     System.out.printf("Ln base10: ");
     value=sc.nextDouble();
     System.out.println(Math.log10(value));
    }
}



     
   