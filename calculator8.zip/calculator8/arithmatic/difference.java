package arithmatic;
import java.util.Scanner;
public class difference
{
	public void diff(){
                  int n,diff;
                  
                  Scanner sc=new Scanner(System.in);

	    System.out.println("enter how many numbers you want difference");
                   n=sc.nextInt();
                   int a[]=new int[n]; 
	    System.out.println("enter the "+n+" numbers in priority ");
                   for(int i=0;i<n;i++)
                   {      
	             System.out.println("enter  number  "+(i+1)+":");
                           a[i]=sc.nextInt();
                   }
                   diff=a[0];
                   for(int i=0;i<(n-1);i++)
                   {
                           diff=diff-a[i+1];
                   }  	    
                   System.out.println("difference of "+n+" numbers is ="+diff);                  
        }      	
}