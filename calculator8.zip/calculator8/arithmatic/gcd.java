package arithmatic;

import java.util.*;



public class gcd  
{  Scanner sc =new Scanner(System.in);
public void gcd()  
{   
int a,b,gcd = 1;  
System.out.print("Enter first Number:");
a=sc.nextInt();
System.out.print("Enter second Number:");
b=sc.nextInt();
 
for(int i = 1; i <= a && i <= b; ++i)   
 {  
  if(a % i == 0 && b % i == 0)   
  gcd = i;  
 }     
 
  System.out.printf("The gcd of %d and %d is %d.\n", a, b, gcd);  
 }  
}  