package arithmatic;
import java.lang.Math;
import java.util.Scanner;

public class square_root{

	public void sqrt(){
	      
                double num;
                Scanner sc=new Scanner(System.in);
                System.out.print("square root ");
		num=sc.nextInt();
		

		// Applying absolute math function and
		// storing it in integer variable
		double value = Math.sqrt(num);

		// Printing value after sqrtfunction
		System.out.println(
			 + value);
	}

}