package arithmatic;
import java.lang.*;
import java.util.*;

public class lnab{
 
  public void lnab()
    {
     Double a,b,value;    
     Scanner sc=new Scanner(System.in);
     System.out.println("enter number:");
     a=sc.nextDouble();
     System.out.println("enter base:");
     b=sc.nextDouble();
     value=((Math.log(a) / Math.log(b)));
     System.out.printf("Log %f base %f = %f ",a,b,value);
    }
}



     
   