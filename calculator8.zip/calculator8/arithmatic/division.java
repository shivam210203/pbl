package arithmatic;
import java.util.Scanner;

public class division {
    public void div(){
    Scanner input = new Scanner (System.in);
    System.out.print("Input the first number: ");
    int a = input.nextInt();
    System.out.print("Input the second number: ");
    int b = input.nextInt();
try {
            System.out.println(a / b); // throw Exception
        }
        catch (ArithmeticException e) {
            // Exception handler
            System.out.println(
                "MATH ERROR:Divided by zero operation cannot possible");
        }
    int r=(a%b);
    System.out.println();

    System.out.println("The remainder of is:" +r);
  }
}

