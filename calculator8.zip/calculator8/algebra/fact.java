package algebra;
import java.lang.*;
import java.util.*;

public class fact
{
// Method to find factorial of given number
public void fact(int num){

  int value = 1, i;
  Scanner sc=new Scanner(System.in);

  for (i=2; i<=num; i++)
    {value*= i;}
  System.out.println("value");
  
 }
}


