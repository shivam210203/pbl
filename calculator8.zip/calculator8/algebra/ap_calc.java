import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.awt.TextField.*;
import java.lang.Math;
 public class ap_calc extends Applet implements ActionListner{
           Textfield one,res; 
           Button sqrt,cbrt;
           public void init(){

           Label l1=new Label("First Number:  ",Label.RIGHT);
           Label l2=new Label("result:  ",Label.RIGHT);

	   one = new TextField(5);
	   res = new TextField(7); 

           sqrt = new Button(sqrt);
           cbrt = new Button(cbrt);    
 
	   add(l1);
	   add(one);
	   add(l1);
	   add(res);

	   add(sqrt);
	   add(cbrt);

           one.addActionListener(this);
           res.addActionListener(this);
           sqrt.addActionListener(this);
           cbrt.addActionListener(this);

      }

   public void actionPerformed(ActionEvent ae){
            string str=ae.getActinCommand();
            float b1,b2=0;
  	    string msg;
            b1 = Float.parseFloat(one.getText())
            if(str.equals("sqrt"))
               b2 = Math.sqrt(b1);

            if(str.equals("cbrt"))
               b2 = Math.cbrt(b1);

            msg= String.valueOf(b3);
            res.setText(msg);
            repaint();
      }

   public void paint(Graphics g){
   }
}

/*
<applet code="ap_calc.class" WIDTH = 460 HEIGHT = 160 >
</applet>
*/
         

                
