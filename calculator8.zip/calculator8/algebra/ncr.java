package algebra;
import java.util.*;

public class ncr{
 
static double nCr(double n, double r)
{
    return fact(n) / (fact(r) *
                  fact(n - r));
}
 
// Returns factorial of n
static double fact(double n)
{
      if(n==0)
      return 1;
    double res = 1;
    for (double i = 2; i <= n; i++)
        res = res * i;
    return res;
}
 
// Driver code
public void ncr()
{   
    double n,r;
    Scanner sc= new Scanner(System.in);
    System.out.print("n:");
    n=sc.nextDouble();
    System.out.println();
    System.out.print("r:");
    r=sc.nextDouble();
    /*int n = 5, r = 3;*/
    System.out.println(nCr(n, r));
}
}