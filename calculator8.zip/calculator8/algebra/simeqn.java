package algebra;

import java.util.*;

public class simeqn{


	Scanner sc = new Scanner(System.in);
         public void simeqn(){

 	   double a,b,c,d,e,f;
           System.out.println("let the 2 equations be a + b = e and c + d = f ");

           System.out.print("a: "); 
           a=sc.nextDouble();
           System.out.print("b: "); 
           b=sc.nextDouble();
           System.out.print("c: "); 
           c=sc.nextDouble();
           System.out.print("d: "); 
           d=sc.nextDouble();
           System.out.print("e: "); 
           e=sc.nextDouble();
           System.out.print("f: "); 
           f=sc.nextDouble();

	   
	   double det = 1/ ((a) * (d) - (b) * (c));
           double x = ((d) * (e) - (b) * (f)) / det;
           double y = ((a) * (f) - (c) * (e)) / det;
           System.out.println("x=" + x + " y=" + y);
 }
}