package arithmetic
import java.io.*;
class div {
	public static void main(String[] args)
	{
          Scanner input = new Scanner (System.in);
    	  System.out.print("Input the first number: ");
   	  int a = input.nextInt();
   	  System.out.print("Input the second number: ");
          int b = input.nextInt();
		try {
			System.out.println(a / b); // throw Exception
		}
		catch (ArithmeticException e) {
			
			System.out.println(
				"Math Error:Division by zero operation cannot possible");
		}
	}
}
