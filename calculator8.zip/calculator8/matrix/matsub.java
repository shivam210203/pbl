package matrix;
import java.util.Scanner;
public class matsub
{
   public void matsub()
   {
      int i,j,k,n;
      Scanner sc=new Scanner(System.in);
      System.out.print("enter order:");
      n=sc.nextInt();
      int a[][]=new int[n][n];
      int b[][]=new int[n][n];
      int c[][]=new int[n][n];

       System.out.println("enter elements of A");      
       for(i=0;i<n;i++)
      {
         for(j=0;j<n;j++)
         {
             System.out.println("enter element:"+i+j);
             a[i][j]=sc.nextInt();
         }
      }
       System.out.println("enter elements of B");     
       for(i=0;i<n;i++)
      {
         for(j=0;j<n;j++)
         {

             System.out.println("enter element:"+i+j);
             b[i][j]=sc.nextInt();
         }
      }
      for(i=0;i<n;i++)
      {
         for(j=0;j<n;j++)
           {
            c[i][j]=0;
            c[i][j]+=a[i][j]-b[i][j];
            System.out.printf(c[i][j]+"    ");
           }

      System.out.println();
      }
   }
}
