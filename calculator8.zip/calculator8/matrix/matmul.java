package matrix;
import java.util.Scanner;
public class matmul
{ 

  public void matmul(){
   int i,j,k,n;
      Scanner sc=new Scanner(System.in);
      System.out.printf("enter matrix order:");
      n=sc.nextInt();
      int a[][]=new int[n][n];
      int b[][]=new int[n][n];
      int c[][]=new int[n][n];
      System.out.println("enter elements of A:");      
       for(i=0;i<3;i++)
      {
         for(j=0;j<3;j++)
         {
             System.out.println("enter element:"+i+j);
             a[i][j]=sc.nextInt();
         }
      }
      System.out.println("enter elements of B:");      
       for(i=0;i<3;i++)
      {
         for(j=0;j<3;j++)
         {
             System.out.println("enter element:"+i+j);
             b[i][j]=sc.nextInt();
         }
      }
      for(i=0;i<3;i++)
      {
         for(j=0;j<3;j++)
         {
            c[i][j]=0;
            for(k=0;k<3;k++)
            {
               c[i][j]+=a[i][k]*b[k][j];
            }
         System.out.printf(c[i][j]+" 	    ");
         }
      System.out.println();
      }
    }
  }


