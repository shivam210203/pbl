package matrix;
import java.util.Scanner;
public class matconstmul
{
   public void matconstmul()
   {
      int i,j,k,n,m;
      Scanner sc=new Scanner(System.in);
      System.out.print("enter constant:");
      m=sc.nextInt();
      System.out.print("enter order:");
      n=sc.nextInt();
      int a[][]=new int[n][n];
      int b[][]=new int[n][n];
      int c[][]=new int[n][n];

       System.out.println("enter elements of A");      
       for(i=0;i<n;i++)
      {
         for(j=0;j<n;j++)
         {
             System.out.println("enter element:"+i+j);
             a[i][j]=sc.nextInt();
         }
      }


      for(i=0;i<n;i++)
      {
         for(j=0;j<n;j++)
           {
            c[i][j]=0;
            c[i][j]+=(m*(a[i][j]));
            System.out.printf(c[i][j]+"    ");
           }

      System.out.println();
      }
   }
}
