package matrix;
import java.util.*;
import java.lang.*;




public class mattranspose{  
   public void mattranspose(){  

      int i,j,k,n;
      Scanner sc=new Scanner(System.in);
      System.out.print("enter order:");
      n=sc.nextInt();
      int a[][]=new int[n][n];   
      int b[][]=new int[n][n];       
       System.out.println("enter elements of A");      
       for(i=0;i<n;i++)
      {
         for(j=0;j<n;j++)
         {
             System.out.println("enter element:"+i+j);
             a[i][j]=sc.nextInt();
         }
      } 
    
    
//Code to transpose a matrix  
for( i=0;i<3;i++){    
for( j=0;j<3;j++){    
b[i][j]=a[j][i];  
}    
}    
  
System.out.println("Printing Matrix without transpose:");  
for(i=0;i<3;i++){    
for(j=0;j<3;j++){    
System.out.print(a[i][j]+" ");    
}    
System.out.println();//new line    
}    
System.out.println("Printing Matrix After Transpose:");  
for(i=0;i<3;i++){    
for(j=0;j<3;j++){    
System.out.print(b[i][j]+" ");    
}    
System.out.println();//new line    
}    
}}  