import arithmatic.*;
import trigo.*;
import basen.*;
import matrix.*;
import java.util.Scanner;
import algebra.*;
import calculus.*;
import others.*;
import statistics.*;
import mensuration.*;


/*System.out.print("To exit press 99 else continue: ");
off=sc.nextInt();*/


class ncalmain
{
  public static void main (String args[])
  {
    int n, ch, num, off = 0;
    Scanner sc = new Scanner (System.in);
    while(off != 99)
     { System.out.printf("1.Arithmatic  	2.Trigonometry  	3.Base-N 	 4.Matrix \n5.Algebra	6.Calculus 		7.Statistics     8.Engineering \n9. Mensuration ");
       System.out.printf (" \n enter choice:");
       ch = sc.nextInt ();
       System.out.println ();
       switch (ch)
         {
           case 1:
     	    {
          System.out.print ("1.sum			");
	     System.out.print ("2.difference		");
	     System.out.println ("3.product		");
    	     System.out.print ("4.divsion 		");
	     System.out.print ("5.modulus		");
	     System.out.println ("6.square root");
	     System.out.print ("7.ln			");
	     System.out.print ("8.ln 10			");
	     System.out.println ("9.log a base b		");
	     System.out.print ("10. cube root 		");
	     System.out.print ("11.power		");
	     System.out.println ("12.factorial");
	     System.out.print ("13.gcd 			");
	     System.out.print ("14.lcm		");
	     System.out.printf (" \n enter choice:");
	     ch = sc.nextInt ();
	     switch (ch)
	     {
	      case 1:
	      {
		     sum a = new sum ();
		     a.sum ();
		     break;
	      }
	      case 2:
	      {
		    difference obj = new difference ();
		    obj.diff ();
		    break;
	      }
	    case 3:
	      {
		    multiplication obj = new multiplication ();
		    obj.mult ();
		    break;
	      }
	    case 4:
	      {
		    division obj = new division ();
		    obj.div ();
		    break;
	      }
	    case 5:
	      {
		    modulus obj = new modulus ();
		    obj.mod ();
		    break;
	      }
	    case 6:
	      {
		    square_root obj = new square_root ();
		    obj.sqrt ();
		    break;
	      }
	    case 7:
	      {
		    ln a = new ln ();
		    a.ln ();
		    break;
	      }
	    case 8:
	      {
	    	     ln10 a = new ln10 ();
	    	     a.ln10 ();
	    	     break;
	      }
	    case 9:
	      {
	     	lnab a = new lnab ();
	    	     a.lnab ();
	     	break;
	      }
	    case 10:
	      {
	          cbrt a = new cbrt ();
	       	a.scbrt ();
	     	break;
	      }

	    case 11:
	      {
	    	     power a = new power ();
	    	     a.power ();
	       	break;
	      }
	    case 12:
	      {
		     System.out.print ("fact ");
	    	     num = sc.nextInt ();
	     	fact a = new fact ();
	       	a.fact (num);
	    	     break;
	      }
	    case 13:
	      {
	    	     gcd a = new gcd();
	    	     a.gcd ();
	       	break;
	      }
	    case 14:
	      {
	    	     lcm a = new lcm();
	    	     a.lcm();
	       	break;
	      }

	    }
          System.out.print("To exit press 99 else continue: ");
          off=sc.nextInt();
	  break;
         
	}
           case 2:
     	    {

    	  System.out.print ("1. sinx		");
	  System.out.print ("2. cosx		");
    	  System.out.println ("3. tanx	");
    	  System.out.print ("4. cosecx	");
	      System.out.print ("5. secx		");
    	  System.out.println ("6. cotx	");
	      System.out.println ();
    	  System.out.print ("7. sin^-1x	");
    	  System.out.print ("8. cos^-1x	");
    	  System.out.println ("9. tan^-1x	");
    	  System.out.print ("10. cosec^-1x	");
    	  System.out.print ("11. secx^-1	");
    	  System.out.println ("12. cot^-1x	");
    	  System.out.println ();
    	  System.out.print ("13. sinhx	");
    	  System.out.print ("14. coshx	");
    	  System.out.println ("15. tanhx	");
    	  System.out.print ("16. cosechx	");
    	  System.out.print ("17. sechx	");
    	  System.out.println ("18. cothx	");
    	  System.out.println ();
    	  System.out.printf (" \n enter choice:");
    	  ch = sc.nextInt ();
	         //            for (int i = 0; i < 30; ++i) System.out.println();

    	  switch (ch)
	      {
     	    case 1:
	           {
	           	sin a = new sin ();
	           	a.sin ();
	    	    break;
	           }
	        case 2:
	           {
	        	cos a = new cos ();
	         	a.cos ();
	        	break;
	           }
	        case 3:
	           {
	        	tan a = new tan ();
	       	    a.tan ();
	    	    break;
	           }
	        case 4:
	           {
		        csc a = new csc ();
		        a.csc ();
		        break;
	           }
	        case 5:
	           {
		        sec a = new sec ();
		        a.sec ();
		        break;
	           }
	        case 6:
	          {
	        	cot a = new cot ();
	        	a.cot ();
	        	break;
	          }

	         case 7:
	          {
	        	invsin a = new invsin ();
	        	a.invsin ();
	        	break;
	          }
	        case 8:
	          {
		        invcos a = new invcos ();
		        a.invcos ();
		        break;
	          }
	        case 9:
	          {
		        invtan a = new invtan ();
		        a.invtan ();
	        	break;
	          }

	        case 10:
	         {
	        	invcsc a = new invcsc ();
	        	a.invcsc ();
	        	break;
	         }
	        case 11:
	          {
		        invsec a = new invsec ();
		        a.invsec ();
		        break;
	         }
	       case 12:
	         {
		        invcot a = new invcot ();
		        a.invcot ();
		        break;
	         }
	      case 13:
	        {
		        sinh a = new sinh ();
	        	a.sinh ();
		        break;
	        }
	      case 14:
	         {
		        cosh a = new cosh ();
		        a.cosh ();
		        break;
	         }
	    case 15:
	         {
		        tanh a = new tanh ();
		        a.tanh ();
		        break;
	         }

	    case 16:
	         {
	        	csch a = new csch ();
		        a.csch ();
		        break;
	         }

	    case 17:
	         {
		        sech a = new sech ();
		        a.sech ();
		        break;
	         }
	    case 18:
	         {
	        	coth a = new coth ();
	        	a.coth ();
		        break;
	         }
	    }
          System.out.print("To exit press 99 else continue: ");
          off=sc.nextInt();
	  break;
	}
           case 3:
     	    {
	     System.out.print ("1. To Binary		");
 	     System.out.print ("2. To Decimal		");
	     System.out.println ("3. Binary sum	");
	     System.out.print ("4. Binary Difference	");
	     System.out.print ("5. Binary product	");
	     System.out.println ("6. Binary division ");
	     System.out.printf (" \n enter choice:");
	     ch = sc.nextInt ();
	     switch (ch)
	      {
	       case 1:
	        {
		    tobin a = new tobin ();
		    System.out.print ("bin ");
		    int in = sc.nextInt ();
		    a.tobin (in);
	         break;
	        }
	       case 2:
	        {
	     	todec a = new todec ();
	     	a.todec ();
	     	break;
	        }
	      case 3:
	        {
	     	binsum a = new binsum ();
	     	a.binsum ();
	     	break;
	        }
	      case 5:
	        {
	     	binmul a = new binmul ();
	     	a.binmul ();
	     	break;
	        }
	      case 4:
	        {
	     	bindif a = new bindif ();
	     	a.bindif ();
	     	break;
	        }
	      case 6:
	        {
	     	bindiv a = new bindiv ();
	     	a.bindiv ();
	     	break;
	        }
	     } 
          System.out.print("To exit press 99 else continue: ");
          off=sc.nextInt();
	  break;
	}
           case 4:
	         {

	  System.out.print ("1. n*Matrix 			");
	  System.out.print ("2. Matrix addition		");
	  System.out.println ("3. Matrix subtraction	");
	  System.out.print ("4. Matrix Multiplication	");
	  System.out.println ("5. Matrix transpose	");

	  System.out.printf (" \n enter choice:");
	  ch = sc.nextInt ();
	  switch (ch)
	    {


	    case 4:
	      {
		matmul a = new matmul ();
		a.matmul ();
		break;
	      }
	    case 2:
	      {
		matadd a = new matadd ();
		a.matadd ();
		break;
	      }
	    case 3:
	      {
		matsub a = new matsub ();
		a.matsub ();
		break;
	      }
	    case 5:
	      {
		mattranspose a = new mattranspose ();
		a.mattranspose ();
		break;
	      }
	    case 1:
	      {
		matconstmul a = new matconstmul ();
		a.matconstmul ();
		break;
	      }
	    }
          System.out.print("To exit press 99 else continue: ");
          off=sc.nextInt();
	  break;
	}
           case 5:
	         {

	  System.out.print ("1. nCr			");
	  System.out.println ("2. Quadratic roots");
	  System.out.print ("3. nPr			");
	  System.out.println ("4. 2 variable simultaneous eqn");
	  System.out.printf (" \n enter choice:");
	  ch = sc.nextInt ();
	  switch (ch)
	    {

	    case 1:
	      {
		ncr a = new ncr ();
		a.ncr ();
		break;
	      }
	    case 2:
	      {
		quad a = new quad ();
		a.quad ();
		break;
	      }
	    case 4:
	      {
		simeqn a = new simeqn ();
		a.simeqn ();
		break;
	      }
	      /*case 2:
	         {
	         npr a=new npr();
	         a.npr();
	         break;
	         } */
	    }
          System.out.print("To exit press 99 else continue: ");
          off=sc.nextInt();
	  break;
	}
           case 6:
	         {

	  System.out.print ("1. d/dx cosx		");
	  System.out.print ("2. d/dx sinx		");
	  System.out.print ("3. d/dx logx		");
	  System.out.println ("4. d/dx x^n	");
	  System.out.print ("5. int sinx		");
	  System.out.print ("6. int cosx		");
	  System.out.println ("7. int x^n		");
	  System.out.printf (" \n enter choice:");
	  ch = sc.nextInt ();
	  switch (ch)
	    {

	    case 1:
	      {
		calcos a = new calcos ();
		a.calcos ();
		break;
	      }
	    case 2:
	      {
		calsin a = new calsin ();
		a.calsin ();
		break;
	      }
	    case 3:
	      {
		callogx a = new callogx ();
		a.callogx ();
		break;
	      }
	    case 4:
	      {
		calxpown a = new calxpown ();
		a.calxpown ();
		break;
	      }
	    case 6:
	      {
		calintcos a = new calintcos ();
		a.calintcos ();
		break;
	      }
	    case 5:
	      {
		calintsin a = new calintsin ();
		a.calintsin ();
		break;
	      }
	    case 7:
	      {
		calintxpown a = new calintxpown ();
		a.calintxpown ();
		break;
	      }
	    }
          System.out.print("To exit press 99 else continue: ");
          off=sc.nextInt();
	  break;
	}
           case 7:
	         {
	  System.out.print ("1. Mean		");
	  System.out.println ("2. Median		");
	  System.out.print ("3. Variance		");
	  System.out.println ("4. Standard Deviation");

	  System.out.printf (" \n enter choice:");
	  ch = sc.nextInt ();
	  switch (ch)
	    {

	    case 1:
	      {
		mean a = new mean ();
		a.mean ();
		break;
	      }
	    case 2:
	      {
		median a = new median ();
		a.median ();
		break;
	      }
	    case 4:
	      {
		stddev a = new stddev ();
		a.stddev ();
		break;
	      }
	    case 3:
	      {
		variance a = new variance ();
		a.variance ();
		break;
	      }
	    }
          System.out.print("To exit press 99 else continue: ");
          off=sc.nextInt();
	  break;
	}
           case 8:
	         {


	  System.out.print ("1. cg translation	");
	  System.out.println ("2. cg rotation	");
	  System.out.print ("3. cg shearing		");
	  System.out.println ("4. cg scaling	");
	  System.out.printf (" \n enter choice:");
	  ch = sc.nextInt ();
	  switch (ch)
	    {

	    case 1:
	      {
		cgtranslation a = new cgtranslation ();
		a.cgtranslation ();
		break;
	      }
	    case 2:
	      {
		cgrotation a = new cgrotation ();
		a.cgrotation ();
		break;
	      }
	    case 3:
	      {
		cgshearing a = new cgshearing ();
		a.cgshearing ();
		break;
	      }
	    case 4:
	      {
		cgscaling a = new cgscaling ();
		a.cgscaling ();
		break;
	      }

	    }
          System.out.print("To exit press 99 else continue: ");
          off=sc.nextInt();
	  break;

	}
           case 9:
	         {

	  System.out.print ("1. square		");
	  System.out.print ("2. rectangle		");
	  System.out.print ("3. triangle		");
	  System.out.println ("4. circle	");
	  System.out.print ("5. trapezium		");
	  System.out.print ("6. cube		");
	  System.out.println ("7. sphere		");
	  System.out.printf (" \n enter choice:");
	  ch = sc.nextInt ();
	  switch (ch)
	    {

	    case 1:
	      {
		sqr a = new sqr ();
		a.sqr ();
		break;
	      }
	    case 2:
	      {
		rect a = new rect ();
		a.rect ();
		break;
	      }
	    case 3:
	      {
		trg a = new trg ();
		a.trg ();
		break;
	      }
	    case 4:
	      {
		trpz a = new trpz ();
		a.trpz ();
		break;
	      }
	    case 5:
	      {
		circ a = new circ ();
		a.circ ();
		break;
	      }
	    case 6:
	      {
		cube a = new cube ();
		a.cube ();
		break;
	      }
	    case 7:
	      {
		sphr a = new sphr ();
		a.sphr ();
		break;
	      }
	    }
          System.out.print("To exit press 99 else continue: ");
          off=sc.nextInt();
	  break;
	}
	   
         }
  
     } 
     
  }
  
}
