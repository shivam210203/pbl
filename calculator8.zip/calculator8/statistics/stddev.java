package statistics;

import java.util.*;
import java.lang.*;

public class stddev
{
  Scanner sc=new Scanner(System.in); 
   public void stddev()
    {      
	   int n,i;
           double sum=0,mean=0;
           System.out.print("Enter number of elements:");
           n=sc.nextInt();
           System.out.println();
	   double a[]=new double[n];
           System.out.print("Enter elements:");
           for(i=0;i<n;i++)
             {a[i]=sc.nextInt();}
	  
	for( i=0;i<n;i++) 
	{
		sum=sum+a[i];
	}
	mean=sum/n;
   
	sum=0;  
	for( i=0;i<n;i++) 
	{
		sum+=Math.pow((a[i]-mean),2);
	
	}
	mean=sum/(n-1);
	double deviation=Math.sqrt(mean);
	System.out.println("standard deviation :"+deviation);

   }
}