package statistics;
import java.util.*;
import java.lang.*;

public class median
{    Scanner sc=new Scanner(System.in); 
	public void median()	
	{
           int n,i;
           System.out.print("Enter number of elements:");
           n=sc.nextInt();
           System.out.println();
	   double a[]=new double[n];
           System.out.print("Enter elements:");
          for(i=0;i<n;i++)
            {a[i]=sc.nextInt();}
	  
	double m=0;
	if(n%2==1)
	{
		m=a[(n+1)/2-1];
	}
	else
	{
		m=(a[n/2-1]+a[n/2])/2;
	}
	
       System.out.println("Median :"+m);
   }
}