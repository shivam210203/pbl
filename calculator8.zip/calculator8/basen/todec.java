package basen;
import java.lang.*;
import java.util.Scanner;

public class todec
  {  
     public void todec()
      {  
         Scanner sc = new Scanner(System.in);
         System.out.print("DEC ");
         String str=sc.nextLine();
         System.out.print(Integer.parseInt(str,2));
     }
  }       