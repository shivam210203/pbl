package basen;
import java.lang.*;
import java.util.*;
public class binmul{
      public void binmul(){
         int a,b,c;
         Scanner sc = new Scanner(System.in);
         System.out.println("enter first number:");
         String str=sc.nextLine();
         a=Integer.parseInt(str,2);

         System.out.println("enter second number:");
         String str1=sc.nextLine();
         b=Integer.parseInt(str1,2);

         c=a*b;
         System.out.print("product is"+Integer.toBinaryString(c));
 }
}