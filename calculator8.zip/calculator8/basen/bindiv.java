package basen;
import java.lang.*;
import java.util.*;
public class bindiv{
      public void bindiv(){
         int a,b,c,d;
         Scanner sc = new Scanner(System.in);
         System.out.println("enter first number:");
         String str=sc.nextLine();
         a=Integer.parseInt(str,2);

         System.out.println("enter second number:");
         String str1=sc.nextLine();
         b=Integer.parseInt(str1,2);

         c=a%b;
         System.out.print("remainder is"+Integer.toBinaryString(c));
         d=a/b;
         System.out.print("quotient is"+Integer.toBinaryString(d));
 }
}