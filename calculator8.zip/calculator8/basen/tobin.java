package basen;
import java.lang.*;
import java.util.*;

public class tobin
  {
     public void tobin(int d)
     {
         System.out.print(Integer.toBinaryString(d));
     }
  }       